import 'package:flutter/material.dart';

class AppColors {
  static Color colorFE6927 = const Color(0xffFE6927);
  static Color colorE6E6E6 = const Color(0xffE6E6E6);
  static Color colorD9D9D9 = const Color(0xffD9D9D9);
  static Color colorffffff = const Color(0xffffffff);
  static Color color000000 = const Color(0xff000000);
  static Color color828282 = const Color(0xff2C2C2D);
  static Color color1C2534 = const Color(0xff1C2534);
  static Color colorEBEBEB = const Color(0xffEBEBEB);
  static Color color645555 = const Color(0xff645555);
  static Color color32BD01 = const Color(0xff32BD01);
  static Color color9a0400 = const Color(0xff9a0400);
  static Color colorF8F8F8 = const Color(0xffF8F8F8);
}
