import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gleekeyu/src/Auth/Login/userLogin_controller.dart';
import 'package:gleekeyu/src/HomePage/homePage_controller.dart';
import 'package:gleekeyu/src/Menu/DashBoard/dashboard_controller.dart';
import 'package:gleekeyu/src/Menu/WishList/AddWishList_Widget/addWishlist_controller.dart';
import 'package:gleekeyu/src/SubPages/Filter/filter_controller.dart';
import 'package:gleekeyu/src/SubPages/PropertyAllDetails/propertyAllDetails_controller.dart';
import 'package:gleekeyu/src/SubPages/SearchPlaces/searchPlaces_controller.dart';
import 'package:permission_handler/permission_handler.dart';
import 'services/firebase_pushNotification_service.dart' show PushNotificationService;
import 'src/Intro_pages/splashScreen.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:firebase_core/firebase_core.dart';
import 'utils/style/constants.dart';


@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  PushNotificationService.setUpInterractedMassage2(message);
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Permission.notification.isDenied.then((value) {
    print("Valueeeee: $value");
    if (value) {
      Permission.notification.request();
    }
  });


  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  try {
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
    await Firebase.initializeApp();
    print("FCM TOKEN:::: ${await FirebaseMessaging.instance.getToken()}");
    await PushNotificationService().setupInteractedMessage();
  } catch (e) {
  }


  await FirebaseMessaging.instance.getInitialMessage().then((message) {
    if (message != null) {
      // 🔥 App close hoy tyare aavi notification thi su open karvu te decide karo
      PushNotificationService.setUpInterractedMassage2(message);
    }
  });


  await Hive.initFlutter();
  await Hive.openBox('gleekey');
  print("FCM Token::  ${await FirebaseMessaging.instance.getToken()}");
  print("Device iddd: ${await _getId()}");

  Get.put(UserLoginController());
  Get.put(FilterController());
  Get.put(SearchPlacesController());
  Get.put(HomePageController());
  Get.put(WishlistController());
  Get.put(DashBoardController());
  Get.put(PropertyAllDetailsController());

  runApp(
    const MyApp(),
  );



}

Future<String?> _getId() async {
  var deviceInfo = DeviceInfoPlugin();
  if (Platform.isIOS) {
    var iosDeviceInfo = await deviceInfo.iosInfo;
    return iosDeviceInfo.identifierForVendor; // unique ID on iOS
  } else if (Platform.isAndroid) {
    var androidDeviceInfo = await deviceInfo.androidInfo;
    return androidDeviceInfo.id; // unique ID on Android
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {

    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle.light.copyWith(
        statusBarColor: Colors.transparent,
      ),
    );
    SystemChrome.setPreferredOrientations(
      [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown],
    );

    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Gleekey',
      theme: ThemeData(
        primaryColor: kOrange,
        primarySwatch: Colors.deepOrange,
        unselectedWidgetColor: kOrange,
        fontFamily: 'HankenGrotesk',
      ),
      builder: (context, child) {
        return SafeArea(
          child: child!,
        );
      },
      supportedLocales: const [Locale('en', 'US')],
      home: SplashPage(),
    );
  }
}
