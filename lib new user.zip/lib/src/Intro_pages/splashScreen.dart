import 'package:easy_splash_screen/easy_splash_screen.dart';
import 'package:get/get.dart';
import 'package:gleekeyu/src/Auth/Login/userLogin_controller.dart';
import 'package:flutter/material.dart';
import 'package:gleekeyu/src/HomePage/homePage_view.dart';
import 'package:gleekeyu/src/Intro_pages/onBoard_screen.dart';
import 'package:gleekeyu/utils/style/constants.dart';

class SplashPage extends StatelessWidget {
  SplashPage({Key? key}) : super(key: key);




  @override
  Widget build(BuildContext context) {
    UserLoginController getController = Get.put(UserLoginController());
    return GetBuilder<UserLoginController>(
      initState: (a) {},
      builder: (a) {
        return EasySplashScreen(
          showLoader: false,
          logoWidth: MediaQuery.of(context).size.width * 0.7,
          logo: Image.asset(
            "assets/images/spalsh.png",
            width: MediaQuery.of(context).size.width * 0.7,
          ),
          backgroundColor: kmatblack,
          navigator: (a.isUserLogedIn || a.isEverLogedin == "true")
              ? const HomePage()
              : const OnBoardScreen(),
          durationInSeconds: 3,
        );
      },
    );
  }
}
