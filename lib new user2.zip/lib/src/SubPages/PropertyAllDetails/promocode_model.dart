class PromocodeModel {
  int? id;
  String? title;
  String? code;
  String? promoCodeType;
  int? codeAmount;
  String? validFrom;
  String? validTill;
  String? promoCodeContent;
  int? useLimite;
  String? status;
  String? createdAt;
  String? updatedAt;
  String? availability;

  PromocodeModel(
      {this.id,
      this.title,
      this.code,
      this.promoCodeType,
      this.codeAmount,
      this.validFrom,
      this.validTill,
      this.promoCodeContent,
      this.useLimite,
      this.status,
      this.createdAt,
      this.updatedAt,
      this.availability});

  PromocodeModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    code = json['code'];
    promoCodeType = json['promo_code_type'];
    codeAmount = json['code_amount'];
    validFrom = json['valid_from'];
    validTill = json['valid_till'];
    promoCodeContent = json['promo_code_content'];
    useLimite = json['use_limite'];
    status = json['status'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    availability = json['availability'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['title'] = this.title;
    data['code'] = this.code;
    data['promo_code_type'] = this.promoCodeType;
    data['code_amount'] = this.codeAmount;
    data['valid_from'] = this.validFrom;
    data['valid_till'] = this.validTill;
    data['promo_code_content'] = this.promoCodeContent;
    data['use_limite'] = this.useLimite;
    data['status'] = this.status;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['availability'] = this.availability;
    return data;
  }
}
