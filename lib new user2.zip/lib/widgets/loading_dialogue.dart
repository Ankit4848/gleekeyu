// import 'package:flutter_spinkit/flutter_spinkit.dart';
// import 'package:flutter/material.dart';

// import '../utils/style/constants.dart';

// class LoadingDialog {
//   static Future<void> showLoadingDialog(
//       BuildContext context, GlobalKey key) async {
//     return showDialog<void>(
//       context: context,
//       builder: (BuildContext context) {
//         return WillPopScope(
//             onWillPop: () async => false,
//             child: Container(
//               height: 50,
//               width: 50,
//               child: SpinKitCircle(
//                 color: kOrange,
//                 size: 45,
//               ),
//             ));
//       },
//     );
//   }
// }
